"use strict";

export default class Note {
    name = '';
    contents = '';

    constructor(name, contents) {
        this.name = name;
        this.contents = contents;
    }
}